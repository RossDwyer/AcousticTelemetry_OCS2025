library(remora)

library(tidyverse)
library(sf)
library(mapview)
library(ggspatial)

browseVignettes(package = "remora")

# ## Create and explore a receiver array report
# shinyReport(type = "receivers")
# 
# ## Create and explore a transmitter report
# shinyReport(type = "transmitters")
# 
# vignette("shinyReport_receivers", package = "remora")
# vignette("shinyReport_transmitters", package = "remora")

# Load the data
files <- list(det = "data/IMOS_pigeye_sample_dataset/IMOS_detections.csv",
              rmeta = "data/IMOS_pigeye_sample_dataset/IMOS_receiver_deployment_metadata.csv",
              tmeta = "data/IMOS_pigeye_sample_dataset/IMOS_transmitter_deployment_metadata.csv",
              meas = "data/IMOS_pigeye_sample_dataset//IMOS_animal_measurements.csv")


# run the QC 
tag_qc <- runQC(x = files, .parallel = TRUE, .progress = TRUE)

## this will only grab the QC flags resulting from the algorithm
grabQC(tag_qc, what = "QCflags")

## this will extract all the relevant data as well as only detections that were deemed `valid` and `likely valid`
qc_data <- grabQC(tag_qc, what = "dQC", flag = c("valid", "likely valid"))
qc_data # our good qc'd dataset with likely valid detections

nqc_data <- grabQC(tag_qc, what = "dQC", flag = c("likely invalid","invalid"))
nqc_data # shows our 2 flagged animals 

plotQC(tag_qc)

# Environmental data
imos_variables()

moor_temp <- mooringTable(sensorType = "temperature")

moor_temp %>% 
  st_as_sf(coords = c("longitude", "latitude"), crs = 4326) %>% 
  mapview(popup = paste("Site code", moor_temp$site_code,"<br>",
                        "URL:", moor_temp$url, "<br>",
                        "Standard names:", moor_temp$standard_names, "<br>",
                        "Coverage start:", moor_temp$time_coverage_start, "<br>",
                        "Coverage end:", moor_temp$time_coverage_end),
          col.regions = "red", color = "white", layer.name = "IMOS Mooring")


det_dist <- getDistance(trackingData = qc_data, 
                        moorLocations = moor_temp,
                        X = "receiver_deployment_longitude",
                        Y = "receiver_deployment_latitude",
                        datetime = "detection_datetime")

mooring_overlap <- getOverlap(det_dist)
mooring_overlap # GBRLSL is the closest mooring with 5073 temperature records

moorIDs <- unique(mooring_overlap$moor_site_code)

moor_data <- mooringDownload(moor_site_codes = "GBRLSL",
                             sensorType = "temperature",
                             fromWeb = FALSE, # True if doing it for 1st time
                             file_loc = "imos.cache/moor/temperature")


## Plot depth time of temperature from one mooring along with the detection data
start_date <- "2023-01-01"
end_date <- "2025-02-01"

plotDT(moorData = moor_data$GBRLSL, 
       moorName = "GBRLSL",
       dateStart = start_date, dateEnd = end_date,
       varName = "temperature",
       trackingData = det_dist,
       speciesID = "Carcharhinus amboinensis",
       IDtype = "species_scientific_name",
       detStart = start_date, detEnd = end_date)

# shallow water
data_with_mooring_sst_all <- extractMoor(
  trackingData=det_dist,
  file_loc="imos.cache/moor/temperature",
  sensorType = "temperature",
  timeMaxh = Inf,
  distMaxkm = Inf,
  targetDepthm = NA,
  scalc = c("min", "max", "mean"))

# Run the same function again with time and distance thresholds
# and when multiple sensors are available return the shallowest value at that time stamp
data_with_mooring_sst_shallow <- extractMoor(trackingData = det_dist,
                                             file_loc="imos.cache/moor/temperature",
                                             sensorType = "temperature",
                                             timeMaxh = 24,
                                             distMaxkm = 500,
                                             targetDepthm=0, 
                                             scalc="min")

data_with_mooring_sst_shallow

# Unnest tibble to reveal the first 10 rows of the data
data_with_mooring_sst_shallow %>% 
  tidyr::unnest(cols = c(data))

# Now plot the environmental data in an abacus plot
summarised_data_id <-
  data_with_mooring_sst_shallow %>% 
  tidyr::unnest(cols = c(data)) %>% 
  mutate(date = as.Date(detection_datetime)) %>% 
  group_by(transmitter_id, date) %>% 
  dplyr::summarise(num_det = n(),
                   mean_temperature = mean(moor_sea_temp, na.rm = T))

library(ggplot2)
ggplot(summarised_data_id, aes(x = date, y = transmitter_id, size = num_det, color = mean_temperature)) +
  geom_point() +
  scale_color_viridis_c() +
  labs(subtitle = "In-situ sea water temperature (°C)") +
  theme_bw()

  