# Load the QC data from session 2
# First lets use the QC data from session 2
qc_data <- read_rds("data/IMOS_pigeye_sample_dataset/IMOS_qc_data.RDS")
# detections <- read_csv("data/IMOS_pigeye_sample_dataset/IMOS_detections.csv")

animal_measurements <- read_csv("data/IMOS_pigeye_sample_dataset/IMOS_animal_measurements.csv") %>% 
  filter(measurement_type=="TOTAL LENGTH")

tag_metadata <- 
  read_csv("data/IMOS_pigeye_sample_dataset/IMOS_transmitter_deployment_metadata.csv") %>% 
  left_join(animal_measurements)

station_info <- read_csv("data/IMOS_pigeye_sample_dataset/IMOS_receiver_deployment_metadata.csv")

# Get the detection dataset from IMOS into the right format for VTrack
detections <-
  qc_data %>% 
  left_join(tag_metadata,keep=FALSE) %>% 
  transmute(transmitter_id = transmitter_id,
            station_name = station_name,
            receiver_name = receiver_name,
            detection_timestamp = detection_datetime,
            longitude = receiver_deployment_longitude,
            latitude = receiver_deployment_latitude,
            sensor_value = (transmitter_sensor_slope*transmitter_sensor_raw_value+transmitter_sensor_intercept),
            sensor_unit = transmitter_sensor_unit)

# Get the transmitter deployemnt dataset from IMOS into the right format for VTrack
tag_metadata <-
  tag_metadata %>% 
  transmute(tag_id = transmitter_deployment_id,
            transmitter_id = transmitter_id,
            scientific_name = species_scientific_name,
            common_name = species_common_name,
            tag_project_name = tag_device_project_name,
            release_id = transmitter_deployment_id,
            release_latitude = transmitter_deployment_latitude,
            release_longitude = transmitter_deployment_longitude,
            ReleaseDate = transmitter_deployment_datetime,
            tag_expected_life_time_days = transmitter_estimated_battery_life,
            tag_status = transmitter_status,
            sex = animal_sex,
            measurement = measurement_value)

# Get the receiver station deployemnt dataset from IMOS into the right format for VTrack
station_info <-
  station_info %>% 
  transmute(station_name = station_name,
            receiver_name = receiver_name,
            installation_name = installation_name,
            project_name = receiver_project_name,
            deploymentdatetime_timestamp = receiver_deployment_datetime,
            recoverydatetime_timestamp = receiver_recovery_datetime,
            station_latitude = receiver_deployment_latitude,
            station_longitude = receiver_deployment_longitude,
            status = active)

# Sets up the data
library(VTrack)
input_data <- setupData(Tag.Detections = detections,
                        Tag.Metadata = tag_metadata,
                        Station.Information = station_info,
                        source = "IMOS")
summary(input_data)

# Detection information
input_data$Tag.Detections

# Tag information
input_data$Tag.Metadata

# Station deployment information
input_data$Station.Information

## plot an abacus plot of tag id
input_data$Tag.Detections %>% 
  mutate(date = date(Date.Time)) %>% 
  group_by(Transmitter, Station.Name, date) %>% 
  summarise(num_detections = n()) %>% 
  ggplot(aes(x = date, y = Transmitter, size = num_detections, color = Station.Name)) +
  geom_point() +
  labs(size = "Number of Detections", color = "Station Name") +
  theme_bw()

## plot an abacus plot of tag id
input_data$Tag.Detections %>% 
  mutate(date = date(Date.Time)) %>% 
  group_by(Transmitter, Station.Name, date) %>% 
  summarise(num_detections = n()) %>% 
  filter(Transmitter=="A69-9001-54409") %>% 
  ggplot(aes(x = date, y = Station.Name, size = num_detections, color = Station.Name)) +
  geom_point() +
  labs(size = "Number of Detections", color = "Station Name") +
  theme_bw()

# plot the map
input_data$Tag.Detections %>% 
  filter(Transmitter=="A69-9001-54409") %>% 
  group_by(Station.Name, Latitude, Longitude) %>% 
  summarise(num_detections = n()) %>% 
  st_as_sf(coords = c("Longitude", "Latitude"), crs = 4326) %>% 
  mapview(cex = "num_detections", 
          zcol = "Station.Name")

## Summarise detections patterns
det_sum <- detectionSummary(ATTdata = input_data, sub = "%Y-%m")

summary(det_sum)

det_sum$Overall
det_sum$Subsetted

# Calculate the mean and standard deviations across sex and month
monthly_detection_index <-
  det_sum$Subsetted %>% 
  mutate(date = lubridate::ymd(paste(subset, 01, "-")),
         month = month(date, label = T, abbr = T)) %>% 
  group_by(Sex, month) %>% 
  summarise(mean_DI = mean(Detection.Index),
            se_DI = sd(Detection.Index)/sqrt(n()))

# Generate a plot using these data
monthly_detection_index %>% 
  ggplot(aes(x = month, y = mean_DI, group = Sex, color = Sex,
             ymin = mean_DI - se_DI, ymax = mean_DI + se_DI)) +
  geom_point() +
  geom_path() +
  geom_errorbar(width = 0.2) +
  labs(x = "Month of year", y = "Mean Detection Index") +
  theme_bw()

## Summarise dispersal patterns
disp_sum <- dispersalSummary(ATTdata = input_data)
disp_sum

monthly_dispersal <-
  disp_sum %>% 
  mutate(Consecutive.Dispersal=units::drop_units(Consecutive.Dispersal)) %>% 
  drop_na(Sex,Consecutive.Dispersal) %>% 
  mutate(month = month(Date.Time, label = T, abbr = T)) %>% 
  group_by(Sex, month) %>% 
  summarise(mean_disp = mean(Consecutive.Dispersal),
            se_disp = sd(Consecutive.Dispersal)/sqrt(n())) %>%
  ungroup()

monthly_dispersal %>% 
  ggplot(aes(x = month, y = mean_disp, group = Sex, color = Sex,
             ymin = mean_disp - se_disp, ymax = mean_disp + se_disp)) +
  geom_point() +
  geom_path() +
  geom_errorbar(width = 0.2) +
  labs(x = "Month of year", y = "Mean Dispersal distance (m)") +
  theme_bw()



# Last lets get it into the old VTrack format
Varchive <- input_data$Tag.Detections %>% 
  transmute(DATETIME=as.POSIXct(Date.Time),
            TRANSMITTERID=as.character(Transmitter),
            SENSOR1=Sensor.Value,
            UNITS1=as.character(Sensor.Unit),
            RECEIVERID=as.character(Receiver),
            STATIONNAME=as.character(Station.Name)) %>% 
  data.frame() # needs to be in this format to run the old VTrack functions

Varchive

Vpoint_file <- input_data$Station.Information %>% 
  group_by(Station.Name) %>% 
  filter(Deployment.Date == max(Deployment.Date)) %>% # Extracts only the latest deployment location for his receiver
  distinct() %>% 
  ungroup() %>% 
  transmute(LOCATION=Station.Name,
            LATITUDE=Station.Latitude,
            LONGITUDE=Station.Longitude,
            RADIUS=0) %>% 
  data.frame() # needs to be in this format to run the old VTrack functions

Vpoint_file 

unique(Varchive$TRANSMITTERID) # Extracts the transmitter code
# [1] "A69-9001-48586" "A69-9001-48595" "A69-9001-48608" "A69-9001-48620" "A69-9001-48621" "A69-9001-54409"

# Run the function to generate the KML for a single transmitter
GenerateAnimationKMLFile_Track(Varchive, # VTrack archive file
                               "A69-9001-48586", # Transmitter code
                               data.frame(Vpoint_file), # points file
                               "images/A69-9001-48586.kml", # file name
                               "cc69deb3", # colour of the track
                               sLocation="STATIONNAME")

# Now last generate residences and movements
Res <- RunResidenceExtraction(Varchive,  # Our data frmae
                              "STATIONNAME",  # Whether we want to work with receiver serial numbers of station names 
                              1, # the minimun number of detections at a receiver to record the presence of a tag             
                              60*60*12, # the time period between detections before a residence efent 'times out'
                              sDistanceMatrix = NULL) # our distance matrix containing distances between receiver locations

# Our residence file
head(Res$residences)

# Our log file
head(Res$residenceslog)

# tally the number of movements between each receiver
Res$nonresidences %>%
  filter (STATIONNAME1!=STATIONNAME2) %>%
  group_by(TRANSMITTERID,STATIONNAME1,STATIONNAME2) %>% 
  count()


